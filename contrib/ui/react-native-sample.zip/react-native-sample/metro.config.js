// Expo: require("expo/metro-config"). Bare RN: require("@react-native/metro-config").
const { getDefaultConfig } = require("expo/metro-config");

const config = getDefaultConfig(__dirname);

// CopilotKit telemetry pulls in `jose`, whose Node build imports node:* modules Hermes cannot bundle.
// Resolve jose (and only jose) against its browser condition. Never assert `browser` globally.
const defaultResolve = config.resolver.resolveRequest;
config.resolver.resolveRequest = (context, moduleName, platform) => {
  const resolve = defaultResolve ?? context.resolveRequest;
  if (moduleName === "jose" || moduleName.startsWith("jose/")) {
    return resolve({ ...context, unstable_conditionNames: ["browser"] }, moduleName, platform);
  }
  return resolve(context, moduleName, platform);
};

module.exports = config;
