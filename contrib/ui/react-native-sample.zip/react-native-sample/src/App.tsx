import { useMemo } from "react";
import { Platform, SafeAreaView, Text, View, StyleSheet } from "react-native";
import { CopilotKitProvider } from "@copilotkit/react-native/headless";
import { CheckoutScreen } from "./CheckoutScreen";
import { ChatSheet } from "./copilot/ChatSheet";

/**
 * The BFF URL. Leave it undefined to run the form against the in-app mock API.
 *  - Android emulator → 10.0.2.2 is the host machine
 *  - iOS simulator    → localhost
 *  - Physical device  → your machine's LAN IP (and the ATS/cleartext entries in app.json)
 */
const BFF_URL: string | undefined = Platform.select({
  android: "http://10.0.2.2:4000",
  default: "http://localhost:4000",
}) as string; // ← set to undefined to use the mock API instead of a real BFF

const TOKEN = "demo-user123"; // ← from your auth store

export default function App() {
  // Keep the token in state in a real app: a refresh must re-render the provider
  // (the provider resolves `headers` on render, not per request).
  const [token] = useMemo(() => [TOKEN], []);
  const headers = useMemo(() => ({ Authorization: `Bearer ${token}` }), [token]);
  const runtimeUrl = `${BFF_URL ?? "http://localhost:4000"}/api/copilotkit`;

  return (
    <CopilotKitProvider runtimeUrl={runtimeUrl} headers={headers}>
      <SafeAreaView style={s.root}>
        <View style={s.banner}>
          <Text style={s.bannerT}>
            {BFF_URL ? "Connected to BFF" : "Mock API (no server)"} · {TOKEN}
          </Text>
        </View>
        <CheckoutScreen bffUrl={BFF_URL} getToken={() => token} />
        {/* The assistant needs a CopilotKit runtime; the form itself works without one. */}
        {BFF_URL ? <ChatSheet /> : <Text style={s.hint}>Set a BFF URL in App.tsx to enable the assistant.</Text>}
      </SafeAreaView>
    </CopilotKitProvider>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#f6f7f9" },
  banner: { backgroundColor: "#101828", paddingVertical: 6, paddingHorizontal: 14 },
  bannerT: { color: "#cdd6e4", fontSize: 12 },
  hint: { padding: 14, color: "#55607a", fontSize: 13 },
});
