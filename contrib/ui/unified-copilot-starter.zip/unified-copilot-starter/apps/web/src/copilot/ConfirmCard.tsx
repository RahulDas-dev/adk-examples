import type { ConfirmCardProps } from "@acme/shared";

export function ConfirmCard({ summary, status, result, onConfirm, onCancel }: ConfirmCardProps) {
  if (status === "complete") {
    const r = safeParse(result);
    return <div className="confirm done">{r?.submitted ? "✔ Order placed" : `Not placed (${r?.reason ?? "cancelled"})`}</div>;
  }
  return (
    <div className="confirm">
      <strong>Confirm your order</strong>
      <p>{summary}</p>
      <div className="row">
        <button disabled={status !== "executing"} onClick={onConfirm}>Place order</button>
        <button className="ghost" disabled={status !== "executing"} onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}
const safeParse = (s?: string) => { try { return s ? JSON.parse(s) : undefined; } catch { return undefined; } };
