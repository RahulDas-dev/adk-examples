import { useMemo } from "react";
import { Platform, SafeAreaView } from "react-native";
import { CopilotKitProvider } from "@copilotkit/react-native/headless";
import { CheckoutScreen } from "./CheckoutScreen";

// Android emulator → 10.0.2.2, iOS sim → localhost, device → LAN IP / HTTPS in prod
const BFF = Platform.OS === "android" ? "http://10.0.2.2:4000" : "http://localhost:4000";

export default function App() {
  const token = "demo-user123"; // ← from your auth store; keep in React state so refreshes re-render the provider
  const headers = useMemo(() => ({ Authorization: `Bearer ${token}` }), [token]);
  return (
    <CopilotKitProvider runtimeUrl={`${BFF}/api/copilotkit`} headers={headers}>
      <SafeAreaView style={{ flex: 1, backgroundColor: "#f6f7f9" }}>
        <CheckoutScreen bffUrl={BFF} getToken={() => token} />
      </SafeAreaView>
    </CopilotKitProvider>
  );
}
