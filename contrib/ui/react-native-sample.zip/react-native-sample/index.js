/**
 * Entry point. ORDER MATTERS:
 *   1. secure RNG        — must be the very first import (CopilotKit's own fallback is not cryptographic)
 *   2. polyfills barrel  — ReadableStream / TextEncoder / DOMException / Headers / streaming fetch for Hermes
 *   3. app
 */
import "react-native-get-random-values";
import "@copilotkit/react-native/polyfills";

import { AppRegistry } from "react-native";
import App from "./src/App";

// Works in Expo too (expo will use this when there is no expo-router entry).
AppRegistry.registerComponent("main", () => App);
