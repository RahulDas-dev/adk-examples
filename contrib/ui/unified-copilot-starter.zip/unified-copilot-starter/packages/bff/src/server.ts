import express from "express";
import cors from "cors";
import { ordersRouter } from "./routes/orders.js";
import { copilotHandler } from "./copilot/runtime.js";

const app = express();
// Native apps don't send Origin; this only matters for the browser.
app.use(cors({ origin: process.env.WEB_ORIGIN ?? true, credentials: true }));

// Copilot runtime BEFORE json body parser (it reads the raw stream itself).
app.use(copilotHandler);
app.use(express.json());
app.use("/api", ordersRouter);

const port = Number(process.env.PORT ?? 4000);
app.listen(port, () => console.log(`BFF on http://localhost:${port}  (REST /api/*, copilot /api/copilotkit)`));
