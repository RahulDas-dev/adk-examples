import { Text, View, StyleSheet } from "react-native";
import type { Spotlight as S } from "./nativeUiAdapter";

/** Rendered INSIDE the ScrollView content, absolutely positioned over the target field. */
export function Spotlight({ s }: { s: S | null }) {
  if (!s) return null;
  return (
    <View pointerEvents="none" style={[styles.ring, { top: s.y - 6, height: s.height + 12 }]}>
      <View style={styles.tip}>
        <Text style={styles.title}>{s.title}</Text>
        {!!s.description && <Text style={styles.desc}>{s.description}</Text>}
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  ring: { position: "absolute", left: 10, right: 10, borderWidth: 3, borderColor: "#2f5bea", borderRadius: 12, backgroundColor: "rgba(47,91,234,0.06)" },
  tip: { position: "absolute", top: "100%", left: 0, marginTop: 6, backgroundColor: "#1b1f24", padding: 10, borderRadius: 8, maxWidth: 280 },
  title: { color: "#fff", fontWeight: "600" },
  desc: { color: "#ddd", marginTop: 2, fontSize: 13 },
});
