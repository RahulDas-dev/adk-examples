import { OrderSchema, createApiClient, ApiError, pageErrors, type ApiClient, type OrderInput, type ApiErrorBody, type ErrorCode } from "../shared";

/**
 * In-app stand-in for the BFF. Same method names and same error shapes as the real
 * ApiClient, so the screens and chatbot tools need no changes when you switch over.
 * It exists so the sample renders and the form/validation flow works with zero servers.
 * The CHAT itself still needs a CopilotKit runtime (an LLM cannot run on the device).
 */
const STOCK: Record<string, { name: string; available: number; price: number }> = {
  "SKU-1001": { name: "Wireless Mouse", available: 12, price: 799 },
  "SKU-2002": { name: "Mechanical Keyboard", available: 2, price: 4499 },
  "SKU-3003": { name: '27" Monitor', available: 0, price: 15999 },
};
const SERVICEABLE = /^(56|40|11|60)\d{4}$/;
const COUPONS: Record<string, number> = { WELCOME10: 0.1 };

function fail(status: number, code: ErrorCode, message: string, extra?: Partial<ApiErrorBody>): never {
  const body: ApiErrorBody = { code, message, ...extra };
  pageErrors.push({ source: "api", endpoint: "/api/orders", status, code, message, fieldErrors: body.fieldErrors, details: body.details });
  throw new ApiError(status, body, "/api/orders");
}

export function createMockApi(): ApiClient {
  return {
    async placeOrder(input: OrderInput) {
      const parsed = OrderSchema.safeParse(input);
      if (!parsed.success) {
        const fieldErrors = Object.fromEntries(parsed.error.issues.map((i) => [String(i.path[0]), i.message]));
        fail(422, "VALIDATION_FAILED", "Some fields are invalid.", { fieldErrors });
      }
      const o = parsed.data;
      const p = STOCK[o.sku];
      if (!p) fail(404, "VALIDATION_FAILED", `Unknown product ${o.sku}`, { fieldErrors: { sku: "Unknown product code" } });
      if (o.qty > p!.available) fail(409, "OUT_OF_STOCK", `Only ${p!.available} left for ${p!.name}.`, { fieldErrors: { qty: `Only ${p!.available} available` }, details: { available: p!.available } });
      if (!SERVICEABLE.test(o.pincode)) fail(422, "PINCODE_NOT_SERVICEABLE", `We don't deliver to ${o.pincode} yet.`, { fieldErrors: { pincode: "Not serviceable" } });
      let discount = 0;
      if (o.coupon) {
        const pct = COUPONS[o.coupon.toUpperCase()];
        if (pct === undefined) fail(422, "COUPON_INVALID", `Coupon ${o.coupon} is invalid or expired.`, { fieldErrors: { coupon: "Invalid coupon" } });
        discount = pct!;
      }
      p!.available -= o.qty;
      return { orderId: `ORD-${Date.now().toString(36).toUpperCase()}`, total: Math.round(p!.price * o.qty * (1 - discount)) };
    },
    async checkStock(sku: string) {
      const p = STOCK[sku];
      if (!p) fail(404, "VALIDATION_FAILED", `Unknown product ${sku}`, { fieldErrors: { sku: "Unknown product code" } });
      return { sku, name: p!.name, available: p!.available };
    },
    async checkPincode(pincode: string) {
      const serviceable = SERVICEABLE.test(pincode);
      return { pincode, serviceable, etaDays: serviceable ? 2 : undefined };
    },
  };
}

/** Real BFF when EXPO_PUBLIC_BFF_URL is set, in-app mock otherwise. Identical surface. */
export type OrderApi = { api: ApiClient; mode: "mock" | "bff" };
export function createOrderApi(bffUrl: string | undefined, getToken: () => string): OrderApi {
  if (!bffUrl) return { api: createMockApi(), mode: "mock" };
  return { api: createApiClient({ baseUrl: bffUrl, getToken }), mode: "bff" };
}
