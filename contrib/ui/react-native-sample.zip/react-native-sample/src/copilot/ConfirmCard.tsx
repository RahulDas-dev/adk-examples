import { View, Text, Pressable, StyleSheet } from "react-native";
import type { ConfirmCardProps } from "@acme/shared";

export function ConfirmCard({ summary, status, result, onConfirm, onCancel }: ConfirmCardProps) {
  if (status === "complete") {
    let r: any; try { r = result ? JSON.parse(result) : undefined; } catch {}
    return <Text style={styles.done}>{r?.submitted ? "✔ Order placed" : `Not placed (${r?.reason ?? "cancelled"})`}</Text>;
  }
  const disabled = status !== "executing";
  return (
    <View style={styles.card}>
      <Text style={styles.h}>Confirm your order</Text>
      <Text>{summary}</Text>
      <View style={styles.row}>
        <Pressable disabled={disabled} onPress={onConfirm} style={[styles.btn, disabled && { opacity: 0.5 }]}><Text style={styles.btnT}>Place order</Text></Pressable>
        <Pressable disabled={disabled} onPress={onCancel} style={[styles.btn, styles.ghost]}><Text>Cancel</Text></Pressable>
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  card: { borderWidth: 1, borderColor: "#ccd", borderRadius: 10, padding: 12, gap: 8, backgroundColor: "#fff" },
  h: { fontWeight: "600" }, row: { flexDirection: "row", gap: 8 },
  btn: { backgroundColor: "#2f5bea", paddingVertical: 8, paddingHorizontal: 14, borderRadius: 8 }, btnT: { color: "#fff" },
  ghost: { backgroundColor: "#eef" }, done: { color: "#1b7f3b", paddingVertical: 4 },
});
