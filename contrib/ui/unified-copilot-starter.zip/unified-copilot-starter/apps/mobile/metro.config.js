// Expo: swap to require("expo/metro-config"). Bare RN: @react-native/metro-config.
const { getDefaultConfig } = require("expo/metro-config");
const path = require("path");

const projectRoot = __dirname;
const workspaceRoot = path.resolve(projectRoot, "../..");
const config = getDefaultConfig(projectRoot);

// Monorepo: let Metro see packages/shared
config.watchFolders = [workspaceRoot];
config.resolver.nodeModulesPaths = [path.resolve(projectRoot, "node_modules"), path.resolve(workspaceRoot, "node_modules")];

// CopilotKit docs: resolve `jose` (transitive via telemetry) to its browser build — Hermes can't bundle node:* imports.
const defaultResolve = config.resolver.resolveRequest;
config.resolver.resolveRequest = (context, moduleName, platform) => {
  const resolve = defaultResolve ?? context.resolveRequest;
  if (moduleName === "jose" || moduleName.startsWith("jose/")) {
    return resolve({ ...context, unstable_conditionNames: ["browser"] }, moduleName, platform);
  }
  return resolve(context, moduleName, platform);
};
module.exports = config;
