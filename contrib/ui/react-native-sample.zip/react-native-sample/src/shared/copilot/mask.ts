import type { FieldRegistry } from "../fields/types";

/** Mask sensitive values before they ever reach the LLM. */
export function maskValues<K extends string>(values: Record<string, unknown>, fields: FieldRegistry<K>) {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(values)) {
    const meta = (fields as Record<string, { sensitive?: boolean }>)[k];
    if (meta?.sensitive && typeof v === "string" && v.length > 0) out[k] = `${"*".repeat(Math.max(0, v.length - 2))}${v.slice(-2)}`;
    else out[k] = v ?? null;
  }
  return out;
}
