import type { RefObject } from "react";
import type { ScrollView, View, TextInput } from "react-native";
import type { UiAdapter, OrderField } from "@acme/shared";

export interface Spotlight { field: OrderField; title: string; description?: string; y: number; height: number }

/**
 * RN implementation of UiAdapter. No DOM: fields register a View ref; we measure it
 * relative to the ScrollView, scroll there, and show a Spotlight overlay (see Spotlight.tsx).
 */
export function createNativeUiAdapter(opts: {
  scrollRef: RefObject<ScrollView | null>;
  fieldRefs: Map<OrderField, View>;
  inputRefs: Map<OrderField, TextInput>;
  getStep: () => number;
  setStep: (n: number) => void;
  showSpotlight: (s: Spotlight | null) => void;
}): UiAdapter<OrderField> {
  const nextFrame = () => new Promise<void>((r) => requestAnimationFrame(() => setTimeout(() => r(), 50)));
  return {
    screenName: "Checkout (mobile)",
    getStep: opts.getStep,
    async goToStep(step) { opts.setStep(step); await nextFrame(); },
    async highlightField(field, title, description) {
      const view = opts.fieldRefs.get(field);
      const scroll = opts.scrollRef.current;
      if (!view || !scroll) return false;
      return new Promise<boolean>((resolve) => {
        view.measureLayout(
          scroll as unknown as View,
          (_x, y, _w, height) => {
            scroll.scrollTo({ y: Math.max(0, y - 120), animated: true });
            opts.showSpotlight({ field, title, description, y, height });
            setTimeout(() => opts.showSpotlight(null), 6000);
            resolve(true);
          },
          () => resolve(false),
        );
      });
    },
    focusField(field) { opts.inputRefs.get(field)?.focus(); },
  };
}
