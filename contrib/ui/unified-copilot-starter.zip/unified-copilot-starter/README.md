# Unified Copilot Starter: one transaction, two front doors

The web page, the React Native screen and the embedded chatbot all share the
same schema, validation, form store, API client and BFF business logic.

```
packages/shared   Zod schema · field map · API client · error store · useOrderForm · useOrderCopilot (the one copilot hook)
packages/bff      Express BFF: REST /api/* (business rules) + CopilotKit runtime /api/copilotkit (same auth)
apps/web          React (Vite) page + CopilotPopup + driver.js highlighting
apps/mobile       React Native (Expo) screen + headless chat sheet + native spotlight
tests/            shared-logic + chatbot-tool tests (run against the live BFF)
```

## What the chatbot can do (same code on web and mobile)
| Tool / context | Purpose |
|---|---|
| context: screen state | step, values (sensitive fields masked), validation errors, recent API/runtime errors |
| context: field map | label, step, on-screen location, visibility rules, error codes |
| `fillOrderForm` | writes chat-collected values into the SAME react-hook-form store; returns invalid/missing |
| `showField` / `goToStep` | navigate + spotlight a field (driver.js on web, overlay on RN); handles hidden GSTIN |
| `checkAvailability` | read-only BFF lookups (same endpoints as the page) |
| `confirmAndSubmitOrder` | human-in-the-loop card, then runs the PAGE's own submit handler |

## Run
```bash
npm install
cp packages/bff/.env.example packages/bff/.env   # set OPENAI_API_KEY (or another provider) + COPILOT_MODEL
npm run dev:bff                                   # http://localhost:4000
npm run dev:web                                   # http://localhost:5173
npm test                                          # needs the BFF running (OPENAI key not needed for tests)
# mobile: add apps/mobile to your RN/Expo app or workspace, `npx expo install`, then `npx expo start`
```
Demo data: SKUs `SKU-1001` (12 in stock), `SKU-2002` (2), `SKU-3003` (0); serviceable pincodes start with 56/40/11/60; coupon `WELCOME10`; token `demo-<userId>`.

## Swap in your real system
- `packages/bff/src/domain/orderService.ts` → call your real services
- `packages/bff/src/auth.ts` → your JWT/session verification (used by REST and copilot)
- `packages/shared/src/schemas` + `fields` → your transaction's schema and field map
- add a new transaction = new schema + field map + `useXxxCopilot` (copy `useOrderCopilot`)

## Verification status
- Type-check passes: shared, bff, web, mobile (RN 0.81 types)
- `npm test`: 19 tests pass (schema rules, masking, API error capture, every chatbot tool handler, confirm→submit success/validation/business-error/cancel), run against the live BFF
- BFF REST + copilot auth checked with curl (401 without token; `/api/copilotkit/info` lists the agent)
- Web bundle compiles (esbuild)
- NOT yet verified: a live LLM conversation (needs your API key); running the mobile app on a device/emulator; the visual look of the driver.js highlight and the RN spotlight
