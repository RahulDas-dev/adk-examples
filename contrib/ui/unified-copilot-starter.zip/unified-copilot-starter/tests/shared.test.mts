import assert from "node:assert/strict";
import { OrderSchema, OrderPatchSchema, maskValues, ORDER_FIELDS, pageErrors, createApiClient, ApiError } from "@acme/shared";

let pass = 0; const t = async (name: string, fn: () => unknown) => { await fn(); pass++; console.log("✔", name); };

const valid = { sku: "SKU-1001", qty: 2, fullName: "Asha Rao", phone: "9876543210", pincode: "560001", address: "12 MG Road, Bengaluru" };

await t("schema accepts a valid order", () => assert.equal(OrderSchema.safeParse(valid).success, true));
await t("schema rejects bad phone/pincode with friendly messages", () => {
  const r = OrderSchema.safeParse({ ...valid, phone: "123", pincode: "56" });
  assert.equal(r.success, false);
  const msgs = r.error!.issues.map((i) => i.message);
  assert.ok(msgs.includes("Enter a 10-digit Indian mobile number"));
  assert.ok(msgs.includes("Pincode must be 6 digits"));
});
await t("GSTIN required only for business orders", () => {
  assert.equal(OrderSchema.safeParse({ ...valid, isBusiness: true }).success, false);
  assert.equal(OrderSchema.safeParse({ ...valid, isBusiness: true, gstin: "29ABCDE1234F1Z5" }).success, true);
});
await t("qty coerced from string (chatbot/text input)", () => assert.equal(OrderSchema.parse({ ...valid, qty: "3" }).qty, 3));
await t("patch schema accepts partial chatbot input", () => assert.equal(OrderPatchSchema.safeParse({ pincode: "560001" }).success, true));
await t("sensitive fields masked before reaching LLM", () => {
  const m = maskValues({ phone: "9876543210", fullName: "Asha" }, ORDER_FIELDS);
  assert.equal(m.phone, "********10"); assert.equal(m.fullName, "Asha");
});
await t("API client records BFF errors into page-error store", async () => {
  pageErrors.clear();
  const api = createApiClient({ baseUrl: "http://127.0.0.1:4000", getToken: () => "demo-u1" });
  await assert.rejects(api.placeOrder({ ...valid, sku: "SKU-2002", qty: 9 }), (e) => e instanceof ApiError && e.body.code === "OUT_OF_STOCK");
  const last = pageErrors.get().at(-1)!;
  assert.equal(last.code, "OUT_OF_STOCK"); assert.equal(last.source, "api"); assert.deepEqual(last.details, { available: 2 });
});
await t("API client: success path", async () => {
  const api = createApiClient({ baseUrl: "http://127.0.0.1:4000", getToken: () => "demo-u1" });
  const r = await api.placeOrder(valid); assert.match(r.orderId, /^ORD-/);
});
await t("API client: missing token → UNAUTHORIZED recorded", async () => {
  pageErrors.clear();
  const api = createApiClient({ baseUrl: "http://127.0.0.1:4000", getToken: () => undefined });
  await assert.rejects(api.checkStock("SKU-1001"));
  assert.equal(pageErrors.get().at(-1)!.code, "UNAUTHORIZED");
});
console.log(`\n${pass} tests passed`);
