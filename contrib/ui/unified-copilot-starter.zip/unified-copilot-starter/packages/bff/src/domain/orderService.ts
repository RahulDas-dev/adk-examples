import { OrderSchema, type OrderInput, type ApiErrorBody } from "@acme/shared";

/**
 * BUSINESS LOGIC LIVES HERE AND ONLY HERE.
 * Called by the REST route (page + chatbot both hit it). Replace the fakes with your real services.
 */
const STOCK: Record<string, { name: string; available: number; price: number }> = {
  "SKU-1001": { name: "Wireless Mouse", available: 12, price: 799 },
  "SKU-2002": { name: "Mechanical Keyboard", available: 2, price: 4499 },
  "SKU-3003": { name: "27\" Monitor", available: 0, price: 15999 },
};
const SERVICEABLE = /^(56|40|11|60)\d{4}$/; // demo: Bengaluru, Mumbai, Delhi, Chennai
const COUPONS: Record<string, number> = { WELCOME10: 0.1 };

export class DomainError extends Error {
  constructor(public status: number, public body: ApiErrorBody) { super(body.message); }
}

export function getStock(sku: string) {
  const p = STOCK[sku];
  if (!p) throw new DomainError(404, { code: "VALIDATION_FAILED", message: `Unknown product ${sku}`, fieldErrors: { sku: "Unknown product code" } });
  return { sku, name: p.name, available: p.available };
}

export function checkPincode(pincode: string) {
  const serviceable = SERVICEABLE.test(pincode);
  return { pincode, serviceable, etaDays: serviceable ? 2 : undefined };
}

export function placeOrder(input: OrderInput, userId: string) {
  // 1) Same schema as the clients — never trust the client (or the LLM).
  const parsed = OrderSchema.safeParse(input);
  if (!parsed.success) {
    const fieldErrors = Object.fromEntries(parsed.error.issues.map((i) => [String(i.path[0]), i.message]));
    throw new DomainError(422, { code: "VALIDATION_FAILED", message: "Some fields are invalid.", fieldErrors });
  }
  const o = parsed.data;

  // 2) Business rules that need server data.
  const stock = getStock(o.sku);
  const product = STOCK[o.sku]!;
  if (o.qty > stock.available) {
    throw new DomainError(409, { code: "OUT_OF_STOCK", message: `Only ${stock.available} left for ${stock.name}.`, fieldErrors: { qty: `Only ${stock.available} available` }, details: { available: stock.available } });
  }
  if (!checkPincode(o.pincode).serviceable) {
    throw new DomainError(422, { code: "PINCODE_NOT_SERVICEABLE", message: `We don't deliver to ${o.pincode} yet.`, fieldErrors: { pincode: "Not serviceable" } });
  }
  let discount = 0;
  if (o.coupon) {
    const pct = COUPONS[o.coupon.toUpperCase()];
    if (pct === undefined) throw new DomainError(422, { code: "COUPON_INVALID", message: `Coupon ${o.coupon} is invalid or expired.`, fieldErrors: { coupon: "Invalid coupon" } });
    discount = pct;
  }

  // 3) Persist (fake).
  product.available -= o.qty;
  const total = Math.round(product.price * o.qty * (1 - discount));
  return { orderId: `ORD-${Date.now().toString(36).toUpperCase()}`, total, userId };
}
