import type { OrderField } from "../schemas/order";
import type { FieldRegistry, StepMeta } from "./types";

export const ORDER_STEPS: StepMeta[] = [
  { step: 1, title: "Product" },
  { step: 2, title: "Shipping" },
  { step: 3, title: "Billing & review" },
];

export const ORDER_FIELDS: FieldRegistry<OrderField> = {
  sku:        { label: "Product code", step: 1, section: "Product card, top" },
  qty:        { label: "Quantity", step: 1, section: "Product card, next to product code" },
  coupon:     { label: "Coupon code", step: 1, section: "Below quantity, 'Have a coupon?' box" },
  fullName:   { label: "Full name", step: 2, section: "Shipping address block, first field" },
  phone:      { label: "Mobile number", step: 2, section: "Shipping address block", sensitive: true },
  pincode:    { label: "Pincode", step: 2, section: "Shipping address block, before address", help: "Delivery availability is checked against this" },
  address:    { label: "Address", step: 2, section: "Shipping address block, last field" },
  isBusiness: { label: "Business purchase", step: 3, section: "Billing, checkbox at top" },
  gstin:      { label: "GSTIN", step: 3, section: "Billing, under 'Business purchase'", visibleWhen: "'Business purchase' is ticked", help: "15 characters, e.g. 29ABCDE1234F1Z5" },
};
