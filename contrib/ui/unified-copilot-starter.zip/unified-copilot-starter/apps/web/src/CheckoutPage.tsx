import { useMemo, useRef, useState } from "react";
import { CopilotPopup, useFrontendTool, useAgentContext, useHumanInTheLoop } from "@copilotkit/react-core/v2";
import { useOrderForm, useOrderCopilot, createApiClient, ORDER_FIELDS, ORDER_STEPS, ApiError, type OrderField } from "@acme/shared";
import { createWebUiAdapter } from "./copilot/webUiAdapter";
import { ConfirmCard } from "./copilot/ConfirmCard";

const hooks = { useFrontendTool, useAgentContext, useHumanInTheLoop };
const STEP_FIELDS: Record<number, OrderField[]> = { 1: ["sku", "qty", "coupon"], 2: ["fullName", "phone", "pincode", "address"], 3: ["isBusiness", "gstin"] };

export function CheckoutPage({ bffUrl, getToken }: { bffUrl: string; getToken: () => string }) {
  const form = useOrderForm();
  const api = useMemo(() => createApiClient({ baseUrl: bffUrl, getToken }), [bffUrl, getToken]);
  const [step, setStep] = useState(1);
  const stepRef = useRef(step); stepRef.current = step;
  const [placed, setPlaced] = useState<string>();
  const ui = useMemo(() => createWebUiAdapter({ getStep: () => stepRef.current, setStep }), []);

  // THE submit handler — used by the button AND by the chatbot's confirm card.
  const submit = form.handleSubmit(async (order) => {
    try {
      const res = await api.placeOrder(order);
      setPlaced(`${res.orderId} · ₹${res.total}`);
    } catch (e) {
      if (e instanceof ApiError && e.body.fieldErrors)
        for (const [f, msg] of Object.entries(e.body.fieldErrors)) form.setError(f as OrderField, { message: msg });
      throw e;
    }
  });

  useOrderCopilot({ hooks, form, ui, api, submit: () => submit(), ConfirmCard });

  const { register, formState: { errors }, watch } = form;
  const isBusiness = watch("isBusiness");
  // plain render function (not a component) so inputs keep focus across re-renders
  const field = (name: OrderField, type = "text") => (
    <label key={name} className="field" data-field={name}>
      <span>{ORDER_FIELDS[name].label}</span>
      <input type={type} {...register(name, type === "number" ? { valueAsNumber: true } : undefined)} />
      {errors[name] && <em>{errors[name]?.message}</em>}
    </label>
  );

  return (
    <main>
      <h1>Checkout</h1>
      <ol className="steps">{ORDER_STEPS.map((s) => <li key={s.step} className={s.step === step ? "on" : ""} onClick={() => setStep(s.step)}>{s.step}. {s.title}</li>)}</ol>
      <form onSubmit={(e) => { e.preventDefault(); submit().catch(() => {}); }}>
        {step === 1 && <>{field("sku")}{field("qty", "number")}{field("coupon")}</>}
        {step === 2 && <>{field("fullName")}{field("phone")}{field("pincode")}{field("address")}</>}
        {step === 3 && <>
          <label className="field check" data-field="isBusiness"><input type="checkbox" {...register("isBusiness")} /> <span>{ORDER_FIELDS.isBusiness.label}</span></label>
          {isBusiness && field("gstin")}
        </>}
        <div className="row">
          {step > 1 && <button type="button" className="ghost" onClick={() => setStep(step - 1)}>Back</button>}
          {step < 3
            ? <button type="button" onClick={async () => (await form.trigger(STEP_FIELDS[step])) && setStep(step + 1)}>Next</button>
            : <button type="submit">Place order</button>}
        </div>
      </form>
      {placed && <p className="ok">Order placed: {placed}</p>}
      <CopilotPopup labels={{ modalHeaderTitle: "Checkout assistant", chatInputPlaceholder: "e.g. Order 2 of SKU-1001 to 560001" }} />
    </main>
  );
}
