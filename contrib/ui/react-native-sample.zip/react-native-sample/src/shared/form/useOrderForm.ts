import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { OrderSchema, type OrderInput, type Order } from "../schemas/order";

/** Same form store on web and mobile. The chatbot writes into THIS, never into the UI directly. */
export function useOrderForm() {
  return useForm<OrderInput, unknown, Order>({
    resolver: zodResolver(OrderSchema),
    mode: "onTouched",
    defaultValues: { qty: 1, isBusiness: false, coupon: "", gstin: "" },
  });
}
