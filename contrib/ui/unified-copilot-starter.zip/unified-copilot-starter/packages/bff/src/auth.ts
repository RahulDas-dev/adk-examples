import type { Request, Response, NextFunction } from "express";

/** Replace with your real session/JWT verification. Shared by REST routes AND the copilot endpoint. */
export function verifyToken(token: string | undefined): { userId: string } | null {
  if (!token) return null;
  return token.startsWith("demo-") ? { userId: token.slice(5) } : null;
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const user = verifyToken(req.header("authorization")?.replace(/^Bearer /, ""));
  if (!user) return res.status(401).json({ code: "UNAUTHORIZED", message: "Session expired — please sign in again." });
  res.locals.user = user;
  next();
}
