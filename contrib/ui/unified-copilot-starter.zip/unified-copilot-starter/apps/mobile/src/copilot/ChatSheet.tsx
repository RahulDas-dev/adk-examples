import { useCallback, useState } from "react";
import { View, Text, TextInput, Pressable, FlatList, StyleSheet, KeyboardAvoidingView, Platform } from "react-native";
import { useAgent, useCopilotKit, useRenderToolCall } from "@copilotkit/react-native/headless";

/**
 * Minimal headless chat (no native peer deps). Swap for `@copilotkit/react-native/components`
 * CopilotChat if you're happy to add @gorhom/bottom-sheet + reanimated.
 */
export function ChatSheet() {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const { copilotkit } = useCopilotKit();
  const { agent } = useAgent({ agentId: "default" });
  const renderToolCall = useRenderToolCall();
  const messages = agent?.messages ?? [];
  const busy = agent?.isRunning ?? false;

  const send = useCallback(async () => {
    const t = text.trim();
    if (!t || busy || !agent) return;
    setText("");
    agent.addMessage({ id: `u-${Date.now()}`, role: "user", content: t });
    await copilotkit.runAgent({ agent });
  }, [text, busy, agent, copilotkit]);

  if (!open) return <Pressable style={st.fab} onPress={() => setOpen(true)}><Text style={st.fabT}>Ask</Text></Pressable>;

  return (
    <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={st.sheet}>
      <View style={st.head}><Text style={{ fontWeight: "600" }}>Checkout assistant</Text><Text onPress={() => setOpen(false)}>Close</Text></View>
      <FlatList
        data={messages}
        keyExtractor={(m, i) => m.id ?? String(i)}
        renderItem={({ item: m }) => {
          if (m.role === "assistant" && (m as any).toolCalls?.length) {
            // Renders the confirm card (useHumanInTheLoop) and any other tool UI inline
            return <View>{(m as any).toolCalls.map((tc: any) => <View key={tc.id}>{renderToolCall({ toolCall: tc, toolMessage: messages.find((x: any) => x.role === "tool" && x.toolCallId === tc.id) as any })}</View>)}</View>;
          }
          if ((m.role === "user" || m.role === "assistant") && typeof m.content === "string" && m.content)
            return <Text style={[st.msg, m.role === "user" ? st.me : st.bot]}>{m.content}</Text>;
          return null;
        }}
      />
      {busy && <Text style={{ color: "#888", padding: 6 }}>Thinking…</Text>}
      <View style={st.row}>
        <TextInput style={st.input} value={text} onChangeText={setText} placeholder="e.g. Ship 2 of SKU-1001 to 560001" onSubmitEditing={send} />
        <Pressable style={st.send} onPress={send}><Text style={{ color: "#fff" }}>Send</Text></Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}
const st = StyleSheet.create({
  fab: { position: "absolute", right: 20, bottom: 30, backgroundColor: "#2f5bea", borderRadius: 28, paddingHorizontal: 22, paddingVertical: 14, elevation: 4 },
  fabT: { color: "#fff", fontWeight: "600" },
  sheet: { position: "absolute", left: 0, right: 0, bottom: 0, height: "55%", backgroundColor: "#fff", borderTopLeftRadius: 16, borderTopRightRadius: 16, padding: 12, elevation: 12, shadowOpacity: 0.15, shadowRadius: 10 },
  head: { flexDirection: "row", justifyContent: "space-between", marginBottom: 8 },
  msg: { padding: 10, borderRadius: 10, marginVertical: 3, maxWidth: "85%" }, me: { alignSelf: "flex-end", backgroundColor: "#e3e9ff" }, bot: { alignSelf: "flex-start", backgroundColor: "#f1f2f4" },
  row: { flexDirection: "row", gap: 8, paddingTop: 6 }, input: { flex: 1, borderWidth: 1, borderColor: "#ccd", borderRadius: 8, padding: 10 },
  send: { backgroundColor: "#2f5bea", borderRadius: 8, paddingHorizontal: 14, justifyContent: "center" },
});
