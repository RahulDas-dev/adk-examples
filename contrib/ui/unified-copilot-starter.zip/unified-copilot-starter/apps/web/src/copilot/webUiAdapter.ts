import { driver } from "driver.js";
import type { UiAdapter, OrderField } from "@acme/shared";

/** Web implementation of the platform-neutral UiAdapter. Fields are found by data-field attributes. */
export function createWebUiAdapter(opts: { getStep: () => number; setStep: (n: number) => void }): UiAdapter<OrderField> {
  const d = driver({ allowClose: true, overlayOpacity: 0.45, stagePadding: 6 });
  const waitForPaint = () => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  return {
    screenName: "Checkout (web)",
    getStep: opts.getStep,
    async goToStep(step) { opts.setStep(step); await waitForPaint(); },
    async highlightField(field, title, description) {
      const el = document.querySelector<HTMLElement>(`[data-field="${field}"]`);
      if (!el) return false;
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      d.highlight({ element: el, popover: { title, description: description ?? "", side: "bottom" } });
      setTimeout(() => d.destroy(), 6000);
      return true;
    },
    focusField(field) { document.querySelector<HTMLElement>(`[data-field="${field}"] input`)?.focus(); },
  };
}
