import { useMemo, useRef, useState } from "react";
import { ScrollView, View, Text, TextInput, Switch, Pressable, StyleSheet } from "react-native";
import { Controller } from "react-hook-form";
import { useFrontendTool, useAgentContext, useHumanInTheLoop } from "@copilotkit/react-native/headless";
import { useOrderForm, useOrderCopilot, ORDER_FIELDS, ORDER_STEPS, ApiError, type OrderField } from "./shared";
import { createOrderApi } from "./mock/mockBff";
import { createNativeUiAdapter, type Spotlight as SpotT } from "./copilot/nativeUiAdapter";
import { Spotlight } from "./copilot/Spotlight";
import { ConfirmCard } from "./copilot/ConfirmCard";
import { ChatSheet } from "./copilot/ChatSheet";

const hooks = { useFrontendTool, useAgentContext, useHumanInTheLoop };
const STEP_FIELDS: Record<number, OrderField[]> = { 1: ["sku", "qty", "coupon"], 2: ["fullName", "phone", "pincode", "address"], 3: ["isBusiness", "gstin"] };

export function CheckoutScreen({ bffUrl, getToken }: { bffUrl?: string; getToken: () => string }) {
  const form = useOrderForm();                                   // ← same hook as web
  const { api, mode } = useMemo(() => createOrderApi(bffUrl, getToken), [bffUrl, getToken]);
  const [step, setStep] = useState(1);
  const stepRef = useRef(step); stepRef.current = step;
  const [spot, setSpot] = useState<SpotT | null>(null);
  const [placed, setPlaced] = useState<string>();
  const scrollRef = useRef<ScrollView>(null);
  const fieldRefs = useRef(new Map<OrderField, View>()).current;
  const inputRefs = useRef(new Map<OrderField, TextInput>()).current;

  const ui = useMemo(() => createNativeUiAdapter({ scrollRef, fieldRefs, inputRefs, getStep: () => stepRef.current, setStep, showSpotlight: setSpot }), []);

  const submit = form.handleSubmit(async (order) => {
    try { const r = await api.placeOrder(order); setPlaced(`${r.orderId} · ₹${r.total}`); }
    catch (e) {
      if (e instanceof ApiError && e.body.fieldErrors)
        for (const [f, msg] of Object.entries(e.body.fieldErrors)) form.setError(f as OrderField, { message: msg });
      throw e;
    }
  });

  useOrderCopilot({ hooks, form, ui, api, submit: () => submit(), ConfirmCard });  // ← same hook as web

  const isBusiness = form.watch("isBusiness");
  const field = (name: OrderField, keyboard: "default" | "number-pad" | "phone-pad" = "default") => (
    <View key={name} ref={(r) => { if (r) fieldRefs.set(name, r); else fieldRefs.delete(name); }} style={s.field}>
      <Text style={s.label}>{ORDER_FIELDS[name].label}</Text>
      <Controller control={form.control} name={name} render={({ field: f, fieldState }) => (
        <>
          <TextInput
            ref={(r) => { if (r) inputRefs.set(name, r); }}
            style={s.input}
            keyboardType={keyboard}
            value={f.value == null ? "" : String(f.value)}
            onBlur={f.onBlur}
            onChangeText={(t) => f.onChange(name === "qty" ? (t === "" ? undefined : Number(t)) : t)}
          />
          {fieldState.error && <Text style={s.err}>{fieldState.error.message}</Text>}
        </>
      )} />
    </View>
  );

  return (
    <View style={{ flex: 1 }}>
      <ScrollView ref={scrollRef} contentContainerStyle={s.page} keyboardShouldPersistTaps="handled">
        <Text style={s.h1}>Checkout</Text>
        <View style={s.steps}>{ORDER_STEPS.map((x) => <Text key={x.step} onPress={() => setStep(x.step)} style={[s.step, x.step === step && s.stepOn]}>{x.step}. {x.title}</Text>)}</View>
        {step === 1 && <>{field("sku")}{field("qty", "number-pad")}{field("coupon")}</>}
        {step === 2 && <>{field("fullName")}{field("phone", "phone-pad")}{field("pincode", "number-pad")}{field("address")}</>}
        {step === 3 && <>
          <View ref={(r) => { if (r) fieldRefs.set("isBusiness", r); }} style={[s.field, s.rowC]}>
            <Controller control={form.control} name="isBusiness" render={({ field: f }) => <Switch value={!!f.value} onValueChange={f.onChange} />} />
            <Text>{ORDER_FIELDS.isBusiness.label}</Text>
          </View>
          {isBusiness && field("gstin")}
        </>}
        <View style={s.rowC}>
          {step > 1 && <Pressable style={[s.btn, s.ghost]} onPress={() => setStep(step - 1)}><Text>Back</Text></Pressable>}
          {step < 3
            ? <Pressable style={s.btn} onPress={async () => (await form.trigger(STEP_FIELDS[step])) && setStep(step + 1)}><Text style={s.btnT}>Next</Text></Pressable>
            : <Pressable style={s.btn} onPress={() => submit().catch(() => {})}><Text style={s.btnT}>Place order</Text></Pressable>}
        </View>
        {placed && <Text style={s.ok}>Order placed: {placed}</Text>}
        <Spotlight s={spot} />
      </ScrollView>
      <ChatSheet />
    </View>
  );
}

const s = StyleSheet.create({
  page: { padding: 20, paddingBottom: 140 }, h1: { fontSize: 24, fontWeight: "700", marginBottom: 12 },
  steps: { flexDirection: "row", gap: 14, marginBottom: 16 }, step: { color: "#888" }, stepOn: { color: "#111", fontWeight: "600" },
  field: { marginBottom: 14, gap: 4 }, label: { fontWeight: "500" }, rowC: { flexDirection: "row", alignItems: "center", gap: 10 },
  input: { borderWidth: 1, borderColor: "#ccd", borderRadius: 8, padding: 10, backgroundColor: "#fff" }, err: { color: "#c62828", fontSize: 13 },
  btn: { backgroundColor: "#2f5bea", paddingVertical: 10, paddingHorizontal: 16, borderRadius: 8 }, btnT: { color: "#fff" }, ghost: { backgroundColor: "#eef" },
  ok: { color: "#1b7f3b", marginTop: 12 },
});
