/** Stable error codes shared by BFF and clients. The chatbot explains errors by code. */
export const ERROR_CODES = {
  VALIDATION_FAILED: "Some fields are invalid.",
  OUT_OF_STOCK: "Requested quantity is not in stock.",
  PINCODE_NOT_SERVICEABLE: "We don't deliver to this pincode yet.",
  COUPON_INVALID: "Coupon is invalid or expired.",
  UNAUTHORIZED: "Session expired — please sign in again.",
  INTERNAL: "Something went wrong on our side.",
} as const;
export type ErrorCode = keyof typeof ERROR_CODES;

export interface ApiErrorBody {
  code: ErrorCode;
  message: string;
  /** field-level problems, keyed by form field name */
  fieldErrors?: Record<string, string>;
  /** extra facts the chatbot can use, e.g. { available: 3 } */
  details?: Record<string, unknown>;
}

export class ApiError extends Error {
  constructor(public status: number, public body: ApiErrorBody, public endpoint: string) {
    super(body.message);
  }
}
