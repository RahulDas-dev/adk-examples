/**
 * The only platform-specific piece. Web implements it with DOM + driver.js,
 * React Native with refs + ScrollView + a tooltip overlay.
 */
export interface UiAdapter<F extends string = string> {
  /** Name of the current screen/route, e.g. "Checkout" */
  screenName: string;
  getStep(): number;
  goToStep(step: number): void | Promise<void>;
  /** scroll to + spotlight a field; resolve false if it isn't rendered */
  highlightField(field: F, title: string, description?: string): boolean | Promise<boolean>;
  focusField?(field: F): void;
}

/**
 * CopilotKit hooks are passed in rather than imported, so this package works
 * with both `@copilotkit/react-core/v2` (web) and `@copilotkit/react-native/headless`
 * (mobile). Both export these hooks with identical signatures.
 */
export interface CopilotHooks {
  useFrontendTool: (tool: any, deps?: ReadonlyArray<unknown>) => void;
  useAgentContext: (ctx: { description: string; value: any }) => void;
  useHumanInTheLoop: (tool: any, deps?: ReadonlyArray<unknown>) => void;
}
