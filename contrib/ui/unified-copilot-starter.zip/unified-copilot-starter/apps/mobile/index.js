import "react-native-get-random-values";          // MUST be first: secure RNG before CopilotKit loads
import "@copilotkit/react-native/polyfills";      // streams, TextEncoder, streaming fetch for Hermes
import { registerRootComponent } from "expo";
import App from "./src/App";
registerRootComponent(App);
