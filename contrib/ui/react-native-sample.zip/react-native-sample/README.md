# React Native sample — checkout screen + embedded assistant

A **standalone** React Native app that demonstrates the shared-logic pattern:
one Zod schema, one form store, one API client and one copilot hook drive the screen
*and* the chatbot. Runs on its own — no monorepo, no server required to use the form.

```
src/shared/          the logic that is identical on web and mobile (schema, fields, api, form, copilot hook)
src/CheckoutScreen   the screen: react-hook-form + the shared copilot hook
src/copilot/         React-Native-only pieces: UiAdapter, Spotlight, ConfirmCard, ChatSheet
src/mock/mockBff.ts  in-app stand-in for the BFF (same method names, same error shapes)
index.js             entry: secure RNG first, then polyfills, then the app
metro.config.js      the jose → browser resolution CopilotKit needs on Hermes
```

## Run it

```bash
npm install
npx expo install          # aligns react-native / react to your Expo SDK
npx expo start            # press a for Android, i for iOS
```

Out of the box it uses the **in-app mock API**: the form, the validation and the error
handling all work with nothing else running. The assistant needs a CopilotKit runtime
(an LLM cannot run on the device), so the Ask button appears once you point the app at a BFF:

```bash
cp .env.example .env      # or edit BFF_URL directly in src/App.tsx
# Android emulator: http://10.0.2.2:4000   iOS simulator: http://localhost:4000
# Physical device:  your machine's LAN IP (see the ATS / cleartext notes below)
```

Run the BFF from the parent starter (`unified-copilot-starter/packages/bff`) and the chat,
the form filling, the field highlighting and the confirm-and-submit card all come alive.

## Try it

| Type into the chat | What happens |
|---|---|
| "Ship 2 of SKU-1001 to 560001" | the bot calls `fillOrderForm`, values appear in the inputs |
| "where do I enter GST?" | the bot calls `showField`, the screen navigates and spotlights the field |
| "is SKU-2002 available?" | the bot calls `checkAvailability` (same endpoint the screen uses) |
| press Place order in the confirm card | the page's own submit runs, then the same REST endpoint |
| submit with pincode 999999 | the BFF error is explained in chat and the field is highlighted |

Demo data: `SKU-1001` (12), `SKU-2002` (2), `SKU-3003` (0); serviceable pincodes start
with 56/40/11/60; coupon `WELCOME10`.

## The three React Native specifics

Everything else is shared with the web app; only these three files are platform-specific.

1. **`src/copilot/nativeUiAdapter.ts`** — implements the shared `UiAdapter` without a DOM:
   each field registers a `ref`, we `measureLayout` it against the ScrollView, scroll to it,
   then render `<Spotlight>`.
2. **`src/copilot/ConfirmCard.tsx`** — the in-chat confirmation UI (React Native `<View>`s).
3. **`src/copilot/ChatSheet.tsx`** — a headless chat using `useAgent` / `useRenderToolCall`.

## Two traps this sample already handles

- **Import order in `index.js`** — `react-native-get-random-values` MUST come before any
  CopilotKit import. Both it and CopilotKit's own polyfill install only if
  `crypto.getRandomValues` is undefined, so whoever loads first wins permanently. If CopilotKit
  loads first you silently get a non-cryptographic `Math.random` fallback.
- **`jose` in `metro.config.js`** — CopilotKit telemetry pulls `jose` in transitively; its Node
  build imports `node:*` modules Hermes cannot bundle. The config resolves `jose` (and only
  `jose`) against its browser condition. Do not assert `browser` globally.

Also worth knowing: **rendering data on screen does not put it in the model's context.**
The screen must call `useAgentContext` explicitly — that is what `useOrderCopilot` does.

## Going to a device

| Setup | BFF URL |
|---|---|
| iOS simulator | `http://localhost:4000` |
| Android emulator | `http://10.0.2.2:4000` |
| Android device on USB | `adb reverse tcp:4000 tcp:4000`, then `localhost` |
| iOS device / any device on the LAN | `http://<your-lan-ip>:4000` + the ATS entry in `app.json` |

Plain `http://` is blocked by both platforms in release builds — `app.json` already carries
the Android cleartext flag and an iOS ATS exception for a LAN IP. In production use HTTPS and
remove both.

## Using bare React Native (no Expo)

Swap the two Expo-specific pieces: `babel.config.js` → `@react-native/babel-preset`,
`metro.config.js` → `require("@react-native/metro-config")`. `app.json` and `npx expo install`
are Expo-only; the app code itself is plain React Native.

## Type-check

```bash
npm run typecheck
```

## Where this fits in the real repo

This sample inlines the shared layer under `src/shared/` so it runs standalone. In the
production repo that same code lives in `packages/shared` and both the web app and this
mobile app import it — see `HANDOVER.md` in `unified-copilot-starter`.
