import { CopilotRuntime, BuiltInAgent } from "@copilotkit/runtime/v2";
import { createCopilotExpressHandler } from "@copilotkit/runtime/v2/express";
import { verifyToken } from "../auth.js";

const SYSTEM_PROMPT = `
You are the checkout assistant embedded in our app (web and mobile).
You help the user complete the SAME checkout form they see on screen.

Rules:
- The app sends "Current checkout screen state" and a "Field map" as context. Treat them as the truth.
  Never claim a field has a value that is not in that context.
- Collect details conversationally, then call fillOrderForm with ONLY the fields the user gave.
  Read its result: ask for anything in "missing", and explain anything in "invalid" in plain words.
- If the user can't find something, call showField. Describe the location using the field map too.
- When the user asks about an error, look at validationErrors and recentErrors (use the error code + details),
  explain the cause in one or two sentences, offer the fix, and call showField on the affected field.
- Use checkAvailability before filling SKU / pincode if the user seems unsure.
- To place the order: only when every required field is valid, call confirmAndSubmitOrder with a short summary.
  Never claim an order was placed unless its result says submitted: true.
- Masked values (****) are sensitive; never ask the user to repeat them in chat unless they are invalid.
`.trim();

/**
 * One agent instance per request: BuiltInAgent refuses concurrent runs on the same instance.
 * The UI tools (fillOrderForm, showField, ...) come from the client per request, so the server needs no tool list.
 */
const runtime = new CopilotRuntime({
  agents: () => ({
    default: new BuiltInAgent({
      model: (process.env.COPILOT_MODEL ?? "openai:gpt-5-mini") as any,
      prompt: SYSTEM_PROMPT,
      maxSteps: 6,
    }),
  }),
});

export const copilotHandler = createCopilotExpressHandler({
  runtime,
  basePath: "/api/copilotkit",
  cors: false, // CORS handled once at the app level
  hooks: {
    // Same auth as the REST API: the chatbot can never do more than the signed-in user.
    onRequest: ({ request }) => {
      const user = verifyToken(request.headers.get("authorization")?.replace(/^Bearer /, "") ?? undefined);
      if (!user) throw new Response(JSON.stringify({ code: "UNAUTHORIZED", message: "Sign in required" }), { status: 401, headers: { "Content-Type": "application/json" } });
    },
  },
});
