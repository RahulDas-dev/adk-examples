import { Router } from "express";
import { DomainError, placeOrder, getStock, checkPincode } from "../domain/orderService.js";
import { requireAuth } from "../auth.js";

/** The REST surface used by web page, mobile screen AND chatbot frontend tools. */
export const ordersRouter = Router();
ordersRouter.use(requireAuth);

const wrap = (fn: (req: any, res: any) => unknown) => async (req: any, res: any) => {
  try { res.json(await fn(req, res)); }
  catch (e) {
    if (e instanceof DomainError) return res.status(e.status).json(e.body);
    console.error(e);
    res.status(500).json({ code: "INTERNAL", message: "Something went wrong on our side." });
  }
};

ordersRouter.post("/orders", wrap((req, res) => placeOrder(req.body, res.locals.user.userId)));
ordersRouter.get("/products/:sku/stock", wrap((req) => getStock(req.params.sku)));
ordersRouter.get("/pincodes/:pincode", wrap((req) => checkPincode(req.params.pincode)));
