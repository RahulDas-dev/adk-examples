// Expo: preset is babel-preset-expo. Bare React Native: @react-native/babel-preset.
module.exports = (api) => {
  api.cache(true);
  return { presets: ["babel-preset-expo"] };
};
