import { z } from "zod";
import { createElement, type ComponentType } from "react";
import type { UseFormReturn } from "react-hook-form";
import { OrderPatchSchema, type OrderInput, type Order, type OrderField } from "../schemas/order";
import { ORDER_FIELDS, ORDER_STEPS } from "../fields/orderFields";
import { usePageErrors, pageErrors } from "../context/pageErrors";
import { ERROR_CODES } from "../api/errors";
import { maskValues } from "./mask";
import type { ApiClient } from "../api/client";
import type { CopilotHooks, UiAdapter } from "./types";

const fieldNames = Object.keys(ORDER_FIELDS) as [OrderField, ...OrderField[]];

interface Args {
  hooks: CopilotHooks;
  form: UseFormReturn<OrderInput, unknown, Order>;
  ui: UiAdapter<OrderField>;
  api: ApiClient;
  /** the page's own submit handler — the chatbot reuses it, never re-implements it */
  submit: () => Promise<void>;
  /** platform UI for the in-chat confirmation (web: <div>, RN: <View>) */
  ConfirmCard: ComponentType<ConfirmCardProps>;
}

export interface ConfirmCardProps {
  summary: string;
  status: "inProgress" | "executing" | "complete" | string;
  result?: string;
  onConfirm: () => void;
  onCancel: () => void;
}

/**
 * ONE hook, used by BOTH the web page and the React Native screen.
 * Registers: live page context (values, errors, field map) + tools (fill, explain, locate, submit).
 */
export function useOrderCopilot({ hooks, form, ui, api, submit, ConfirmCard }: Args) {
  const { useAgentContext, useFrontendTool, useHumanInTheLoop } = hooks;
  const values = form.watch();
  const { errors, isSubmitting } = form.formState;
  const recentErrors = usePageErrors();

  // ---------- 1. PAGE CONTEXT (read) ----------
  useAgentContext({
    description: "Current checkout screen state. Use it to answer questions; never invent field values.",
    value: {
      screen: ui.screenName,
      currentStep: { number: ui.getStep(), title: ORDER_STEPS[ui.getStep() - 1]?.title, total: ORDER_STEPS.length },
      values: maskValues(values as Record<string, unknown>, ORDER_FIELDS),
      validationErrors: Object.fromEntries(Object.entries(errors).map(([k, e]) => [k, (e as { message?: string })?.message ?? "invalid"])),
      recentErrors: recentErrors.map(({ source, code, message, endpoint, details, fieldErrors }) => ({ source, code, message, endpoint, details, fieldErrors })),
      isSubmitting,
    },
  });
  useAgentContext({
    description: "Field map of the checkout screen: label, wizard step, on-screen location, visibility rules",
    value: { steps: ORDER_STEPS, fields: ORDER_FIELDS as unknown as Record<string, unknown>, errorCodes: ERROR_CODES },
  });

  // ---------- 2. FILL THE FORM (write through the SAME form store) ----------
  useFrontendTool({
    name: "fillOrderForm",
    description: "Write values the user gave in chat into the checkout form. Only pass fields the user actually provided. Returns which fields are still missing or invalid.",
    parameters: OrderPatchSchema,
    handler: async (patch: z.infer<typeof OrderPatchSchema>) => {
      const applied: string[] = [];
      for (const [k, v] of Object.entries(patch)) {
        if (v === undefined) continue;
        form.setValue(k as OrderField, v as never, { shouldDirty: true, shouldTouch: true });
        applied.push(k);
      }
      await form.trigger(applied as OrderField[]);           // same zod rules as manual typing
      // getFieldState reads live state; formState.errors can be stale outside render (tool calls)
      const invalid = Object.fromEntries(applied
        .map((k) => [k, form.getFieldState(k as OrderField).error?.message] as const)
        .filter(([, m]) => m));
      const current = form.getValues();
      const missing = fieldNames.filter((f) => {
        if (f === "coupon") return false;
        if (f === "gstin") return current.isBusiness && !current.gstin;
        const val = current[f];
        return val === undefined || val === "" || val === null;
      });
      return JSON.stringify({ applied, invalid, missing });
    },
  }, [form]);

  // ---------- 3. GUIDE: navigate + highlight ----------
  useFrontendTool({
    name: "showField",
    description: "Navigate to the step containing a field and visually highlight it, so the user can find it. Use when the user can't find something or to point at an invalid field.",
    parameters: z.object({ field: z.enum(fieldNames).describe("Form field key") }),
    handler: async ({ field }: { field: OrderField }) => {
      const meta = ORDER_FIELDS[field];
      if (field === "gstin" && !form.getValues("isBusiness")) {
        await ui.goToStep(meta.step);
        await ui.highlightField("isBusiness", ORDER_FIELDS.isBusiness.label, "Tick this first to show the GSTIN field");
        return "GSTIN is hidden until 'Business purchase' is ticked; highlighted that checkbox instead.";
      }
      if (ui.getStep() !== meta.step) await ui.goToStep(meta.step);
      const ok = await ui.highlightField(field, meta.label, meta.help);
      ui.focusField?.(field);
      return ok ? `Highlighted ${meta.label} (${meta.section}, step ${meta.step}).` : `Could not render ${meta.label} — describe its location instead: ${meta.section}.`;
    },
  }, [ui, form]);

  useFrontendTool({
    name: "goToStep",
    description: "Move the checkout wizard to a step (1 Product, 2 Shipping, 3 Billing & review).",
    parameters: z.object({ step: z.number().int().min(1).max(ORDER_STEPS.length) }),
    handler: async ({ step }: { step: number }) => { await ui.goToStep(step); return `Now on step ${step}.`; },
  }, [ui]);

  // ---------- 4. READ-ONLY BACKEND LOOKUPS (same BFF endpoints the page uses) ----------
  useFrontendTool({
    name: "checkAvailability",
    description: "Check stock for a product code and/or delivery for a pincode before filling.",
    parameters: z.object({ sku: z.string().optional(), pincode: z.string().optional() }),
    handler: async ({ sku, pincode }: { sku?: string; pincode?: string }) => {
      const out: Record<string, unknown> = {};
      if (sku) out.stock = await api.checkStock(sku).catch((e) => ({ error: e.body ?? String(e) }));
      if (pincode) out.delivery = await api.checkPincode(pincode).catch((e) => ({ error: e.body ?? String(e) }));
      return JSON.stringify(out);
    },
  }, [api]);

  // ---------- 5. SUBMIT — human approves in the chat, then the PAGE's submit runs ----------
  useHumanInTheLoop({
    name: "confirmAndSubmitOrder",
    description: "When all fields are valid, show the user a summary and ask them to confirm. Never submit without this.",
    parameters: z.object({ summary: z.string().describe("Short order summary for the user to confirm") }),
    render: (props: any) =>
      createElement(ConfirmCard, {
        summary: props.args?.summary ?? "",
        status: props.status,
        result: props.result,
        onCancel: () => props.respond?.({ submitted: false, reason: "user_cancelled" }),
        onConfirm: async () => {
          const ok = await form.trigger();                       // same validation
          if (!ok) {
            const fields = (Object.keys(ORDER_FIELDS) as OrderField[]).filter((f) => form.getFieldState(f).error);
            return props.respond?.({ submitted: false, reason: "validation", fields });
          }
          pageErrors.clear();
          try { await submit(); props.respond?.({ submitted: true }); }  // same submit + same API call
          catch { props.respond?.({ submitted: false, reason: "api", errors: pageErrors.get() }); }
        },
      }),
  }, [form, submit, ConfirmCard]);
}
