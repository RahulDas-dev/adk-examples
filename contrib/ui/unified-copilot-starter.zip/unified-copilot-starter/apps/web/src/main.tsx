import React from "react";
import { createRoot } from "react-dom/client";
import { CopilotKit } from "@copilotkit/react-core/v2";
import "@copilotkit/react-core/v2/styles.css";
import "driver.js/dist/driver.css";
import { pageErrors } from "@acme/shared";
import { CheckoutPage } from "./CheckoutPage";
import "./styles.css";

const BFF = import.meta.env.VITE_BFF_URL ?? "http://localhost:4000";
const token = "demo-user123"; // ← from your auth/session

// Runtime errors → page error store → chatbot can explain them
window.addEventListener("error", (e) => pageErrors.push({ source: "runtime", message: e.message }));
window.addEventListener("unhandledrejection", (e) => {
  if ((e.reason as any)?.body?.code) return; // ApiErrors are already recorded by the API client
  pageErrors.push({ source: "runtime", message: String((e.reason as any)?.message ?? e.reason) });
});

createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <CopilotKit runtimeUrl={`${BFF}/api/copilotkit`} headers={{ Authorization: `Bearer ${token}` }}>
      <CheckoutPage bffUrl={BFF} getToken={() => token} />
    </CopilotKit>
  </React.StrictMode>,
);
