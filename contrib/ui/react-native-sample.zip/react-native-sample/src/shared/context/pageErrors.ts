import { useSyncExternalStore } from "react";

export interface PageError {
  source: "api" | "runtime" | "validation";
  message: string;
  code?: string;
  endpoint?: string;
  status?: number;
  details?: Record<string, unknown>;
  fieldErrors?: Record<string, string>;
  at?: number;
}

/** Tiny framework-free store: last N errors seen on the screen. */
function createErrorStore(max = 5) {
  let errors: PageError[] = [];
  const listeners = new Set<() => void>();
  const emit = () => listeners.forEach((l) => l());
  return {
    push(e: PageError) { errors = [...errors, { ...e, at: Date.now() }].slice(-max); emit(); },
    clear() { errors = []; emit(); },
    get: () => errors,
    subscribe(l: () => void) { listeners.add(l); return () => { listeners.delete(l); }; },
  };
}
export const pageErrors = createErrorStore();
export const usePageErrors = () => useSyncExternalStore(pageErrors.subscribe, pageErrors.get, pageErrors.get);
