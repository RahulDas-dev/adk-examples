import assert from "node:assert/strict";
import React, { createElement } from "react";
import TestRenderer, { act } from "react-test-renderer";
import { useOrderForm, useOrderCopilot, createApiClient, pageErrors } from "@acme/shared";
(globalThis as any).IS_REACT_ACT_ENVIRONMENT = true;

// Fake CopilotKit hooks: capture what the shared hook registers
const tools: Record<string, any> = {}; const contexts: Record<string, any> = {};
const hooks = {
  useFrontendTool: (t: any) => { tools[t.name] = t; },
  useHumanInTheLoop: (t: any) => { tools[t.name] = t; },
  useAgentContext: (c: any) => { contexts[c.description] = c.value; },
};
let step = 1; const calls: string[] = [];
const ui = {
  screenName: "test", getStep: () => step,
  goToStep: (s: number) => { step = s; calls.push(`goto:${s}`); },
  highlightField: (f: string) => { calls.push(`hl:${f}`); return true; },
  focusField: (f: string) => calls.push(`focus:${f}`),
};
const api = createApiClient({ baseUrl: "http://127.0.0.1:4000", getToken: () => "demo-u1" });
let form: any; let submitted = 0;
const Confirm = () => null;

function Harness() {
  form = useOrderForm();
  const submit = form.handleSubmit(async (o: any) => { await api.placeOrder(o); submitted++; });
  useOrderCopilot({ hooks, form, ui, api, submit: () => submit(), ConfirmCard: Confirm });
  return null;
}
let r: any; await act(async () => { r = TestRenderer.create(createElement(Harness)); });

let pass = 0; const t = async (n: string, fn: () => unknown) => { await fn(); pass++; console.log("✔", n); };
const ctx = () => contexts[Object.keys(contexts).find((k) => k.startsWith("Current checkout"))!];

await t("registers all tools + 2 contexts", () => {
  assert.deepEqual(Object.keys(tools).sort(), ["checkAvailability", "confirmAndSubmitOrder", "fillOrderForm", "goToStep", "showField"]);
  assert.equal(Object.keys(contexts).length, 2);
});
await t("fillOrderForm writes into the SAME form store + reports invalid/missing", async () => {
  let out: any; await act(async () => { out = JSON.parse(await tools.fillOrderForm.handler({ sku: "SKU-1001", qty: 2, phone: "123" })); });
  assert.equal(form.getValues("sku"), "SKU-1001");
  assert.ok(out.invalid.phone, "phone flagged invalid by the shared zod schema");
  assert.ok(out.missing.includes("fullName") && out.missing.includes("pincode"));
});
await t("context reflects values (phone masked) + validation errors", () => {
  const c = ctx(); assert.equal(c.values.sku, "SKU-1001"); assert.equal(c.values.phone, "*23"); assert.ok(c.validationErrors.phone);
});
await t("showField navigates to the right step and highlights", async () => {
  calls.length = 0; await act(async () => { await tools.showField.handler({ field: "pincode" }); });
  assert.deepEqual(calls, ["goto:2", "hl:pincode", "focus:pincode"]);
});
await t("showField on hidden GSTIN points to the 'Business purchase' checkbox", async () => {
  calls.length = 0; let msg = ""; await act(async () => { msg = await tools.showField.handler({ field: "gstin" }); });
  assert.deepEqual(calls, ["goto:3", "hl:isBusiness"]); assert.match(msg, /hidden/);
});
await t("checkAvailability calls the same BFF endpoints", async () => {
  const out = JSON.parse(await tools.checkAvailability.handler({ sku: "SKU-1001", pincode: "999999" }));
  assert.equal(out.stock.sku, "SKU-1001"); assert.equal(out.delivery.serviceable, false);
});
await t("confirm → page submit: validation failure is reported, nothing sent", async () => {
  let resp: any; const el = tools.confirmAndSubmitOrder.render({ args: { summary: "x" }, status: "executing", respond: async (v: any) => { resp = v; } });
  await act(async () => { await el.props.onConfirm(); });
  assert.equal(resp.submitted, false); assert.equal(resp.reason, "validation"); assert.equal(submitted, 0);
});
await t("confirm → page submit: BFF business error (pincode) surfaced to chatbot", async () => {
  await act(async () => { await tools.fillOrderForm.handler({ phone: "9876543210", fullName: "Asha Rao", pincode: "999999", address: "12 MG Road, Bengaluru" }); });
  let resp: any; const el = tools.confirmAndSubmitOrder.render({ args: { summary: "x" }, status: "executing", respond: async (v: any) => { resp = v; } });
  await act(async () => { await el.props.onConfirm(); });
  assert.equal(resp.submitted, false); assert.equal(resp.reason, "api");
  assert.equal(resp.errors.at(-1).code, "PINCODE_NOT_SERVICEABLE");
  assert.equal(ctx().recentErrors.at(-1).code, "PINCODE_NOT_SERVICEABLE");
});
await t("confirm → page submit: success uses the same submit + API", async () => {
  await act(async () => { await tools.fillOrderForm.handler({ pincode: "560001" }); });
  let resp: any; const el = tools.confirmAndSubmitOrder.render({ args: { summary: "x" }, status: "executing", respond: async (v: any) => { resp = v; } });
  await act(async () => { await el.props.onConfirm(); });
  assert.deepEqual(resp, { submitted: true }); assert.equal(submitted, 1);
});
await t("cancel does not submit", async () => {
  let resp: any; const el = tools.confirmAndSubmitOrder.render({ args: { summary: "x" }, status: "executing", respond: async (v: any) => { resp = v; } });
  el.props.onCancel(); assert.equal(resp.reason, "user_cancelled"); assert.equal(submitted, 1);
});
r.unmount(); console.log(`\n${pass} tests passed`);
