import { z } from "zod";

/**
 * SINGLE SOURCE OF TRUTH for the "Place order" transaction.
 * Imported by: web form, mobile form, chatbot tools, and the BFF.
 * `.describe()` text is what the LLM reads — write it for a human.
 */
export const OrderSchema = z.object({
  // Step 1 — Product
  sku: z.string().regex(/^SKU-\d{3,6}$/, "Use a product code like SKU-1234").describe("Product code, e.g. SKU-1234"),
  qty: z.coerce.number().int().min(1, "Minimum 1").max(20, "Maximum 20 per order").describe("Quantity, 1-20"),
  coupon: z.string().trim().max(20).optional().describe("Optional coupon code"),

  // Step 2 — Shipping
  fullName: z.string().trim().min(2, "Enter your full name").describe("Recipient's full name"),
  phone: z.string().regex(/^[6-9]\d{9}$/, "Enter a 10-digit Indian mobile number").describe("10-digit mobile number"),
  pincode: z.string().regex(/^\d{6}$/, "Pincode must be 6 digits").describe("6-digit delivery pincode"),
  address: z.string().trim().min(10, "Address looks too short").describe("Street address, house/flat number"),

  // Step 3 — Billing
  isBusiness: z.boolean().default(false).describe("True if buying for a business (enables GST invoice)"),
  gstin: z.string().optional().describe("15-char GSTIN, required only when isBusiness is true"),
}).superRefine((v, ctx) => {
  if (v.isBusiness && !/^\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(v.gstin ?? "")) {
    ctx.addIssue({ code: "custom", path: ["gstin"], message: "Valid 15-character GSTIN required for business orders" });
  }
});

export type OrderInput = z.input<typeof OrderSchema>;
export type Order = z.output<typeof OrderSchema>;
export type OrderField = keyof OrderInput;

/** Shape the chatbot may fill: any subset, raw (unvalidated) values. Validation runs in the form. */
export const OrderPatchSchema = z.object({
  sku: z.string().optional(),
  qty: z.number().optional(),
  coupon: z.string().optional(),
  fullName: z.string().optional(),
  phone: z.string().optional(),
  pincode: z.string().optional(),
  address: z.string().optional(),
  isBusiness: z.boolean().optional(),
  gstin: z.string().optional(),
}).describe("Any subset of order fields collected from the user");
