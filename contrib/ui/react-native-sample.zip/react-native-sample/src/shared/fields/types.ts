/** Metadata the chatbot uses to explain and locate fields. Platform-neutral. */
export interface FieldMeta {
  label: string;
  step: number;          // 1-based wizard step
  section: string;       // human description of where it is on screen
  help?: string;         // hints, visibility conditions
  sensitive?: boolean;   // masked before being sent to the LLM
  visibleWhen?: string;  // human-readable condition, e.g. "Business purchase is ticked"
}
export type FieldRegistry<K extends string> = Record<K, FieldMeta>;
export interface StepMeta { step: number; title: string }
