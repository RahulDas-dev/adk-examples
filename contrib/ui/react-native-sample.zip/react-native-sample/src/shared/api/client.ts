import { ApiError, type ApiErrorBody } from "./errors";
import { pageErrors } from "../context/pageErrors";
import type { OrderInput } from "../schemas/order";

export interface ApiClientOptions {
  baseUrl: string;
  getToken: () => string | undefined | Promise<string | undefined>;
}

/** The ONLY way web, mobile and chatbot tools talk to the BFF. */
export function createApiClient({ baseUrl, getToken }: ApiClientOptions) {
  async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
    const token = await getToken();
    const res = await fetch(`${baseUrl}${path}`, {
      method,
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    if (!res.ok) {
      const err: ApiErrorBody = await res.json().catch(() => ({ code: "INTERNAL", message: res.statusText }));
      // Every API failure lands in the page-error store → the chatbot can explain it.
      pageErrors.push({ source: "api", endpoint: path, status: res.status, code: err.code, message: err.message, details: err.details, fieldErrors: err.fieldErrors });
      throw new ApiError(res.status, err, path);
    }
    return res.json() as Promise<T>;
  }

  return {
    placeOrder: (o: OrderInput) => request<{ orderId: string; total: number }>("POST", "/api/orders", o),
    checkStock: (sku: string) => request<{ sku: string; available: number; name: string }>("GET", `/api/products/${encodeURIComponent(sku)}/stock`),
    checkPincode: (pincode: string) => request<{ pincode: string; serviceable: boolean; etaDays?: number }>("GET", `/api/pincodes/${pincode}`),
  };
}
export type ApiClient = ReturnType<typeof createApiClient>;
